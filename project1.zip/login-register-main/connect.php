<?php 
	$db_name = 'mysql:host=localhost;dbname=id21672098_loginn_db';
	$user_name = 'id21672098_roottt';
	$user_password = 'Gotogoto1998!';

	$conn = new PDO($db_name, $user_name, $user_password);
	if (!$conn) {
		echo "did not connected";
	}
?>

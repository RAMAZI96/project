

let is = true;
document.querySelector(".wow").onclick=function(){
    if(is){

    document.querySelector(".show").style.display="block";
   
is = false;
}
else{
    document.querySelector(".show").style.display = "none";
    
    is = true;
    
}
}

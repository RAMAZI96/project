<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fashion Lifestyle Website</title>
  <link rel="stylesheet" href="styy.css" >
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" 
  integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" 
  integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</head>
<body>
<div class="header">
    <div class="container">
<div class="navbar"> <div class="wow">
  <a href="register.php"> SIGN IN</a>
   
</div>
    <div class="logo">
        <img src="image00.jpg" alt="" width="140px" height="30px">
    </div>
    <nav>
        <ul id="MenuItems">
            <li><a href="index.html">Home</a> </li>
           
           
            <li><a href="">Contact</a> </li>
            
            <li>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="search">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                      </div></div>
                </li>
               
        </ul>
    </nav>
    
    <img src="menu1.png"  class="menu-icon" onclick="menutoggle()">
</div></div></div>
<section class="header">                 

      
      <div class="banner">
        <div class="banner-img">
          <img src="images/banner2.jpg" >
        </div>
      
        <div class="banner-title">
          <h1>FASHION STORY</h1>
          <h1>WOMEN'S LIFESYLE </h1>
        </div>
      </div>
      
</section>



<!--------fashion trends----->

  <div class="container">
    <div  class="fashion-box">
    <div class="text-center">
    <div class="show">
                <div class="sshow"> 
                  <p class="text-center"><span><?= $fetch_profile['name']; ?></span></p>
                  <p class="text-center"><span><?= $fetch_profile['email']; ?><span></p> 
                  <a href="logout.php"><input type="button" class="btn btn-primary " value="logout"></a></div> 
</div></div>
      <div class="title-style text-center">
    
      <h1>FASHION TRENDS</h1>
    </div>
      <P class="text-center"> From the return of 90s up-dos and 
        side parts to the “poolside slick” British Vogue's Acting Beauty Director Lauren 
        Murdoch-Smith is here to guide us through the spring's 
        most wearable hair trends…</P>
    </div>
    <div class="row ">
      <div class="col-md-4 text-center">
        <div class="trending-img">
          <img src="images/foto1.webp">
          <button type="button" class="btn-buy">Buy Now</button>
          <div class="overlay"></div>
        </div>
      </div>
      <div class="col-md-4 text-center">
        <div class="trending-img">
          <img src="images/foto3.webp">
          <button type="button" class="btn-buy">Buy Now</button>
          <div class="overlay"></div>
        </div>
      </div>
      <div class="col-md-4 text-center">
        <div class="trending-img">
          <img src="images/women2.webp">
          <button type="button" class="btn-buy">Buy Now</button>
          <div class="overlay"></div>
        </div>
      </div>
    </div>
  </div>

</section>

<!--------offer-------->

<section class="offer">
<div class="row">
  <div class="col-md-6 text-center">
    <img src="images/women3.webp">
  </div>
  <div class="col-md-6">
    <div class="yuti">
    <div class="subscribe" >
      <h4>FUNSHION EXCLUSIVE</h4>
      <P>Subscribe Easy Tutorials YouTube channel 
        to watch more videos on Web Designing, 
        Graphics Designing and Digital Marketing. 
        Press the bell navbar-toggler-icon
      to get immediate notification for latest videos  </P>
      <a  href="#">Subscribe</a>
    </div>
    </div>
  </div>
</div>
</section>
   

<!--------LATEST BLOG-------->

<section class="fashion-blog">
  <div class="fashion-box">
    <div class="title-style text-center">
    <h1>LATEST FASHION BLOG</h1>
  </div>
  <div class="container">
    <div class="row text-center ">
      <div class="col-md-4 ">
        <div class="blog-img ">
          <img src="images/blog1.jpg">
        </div>
        <h5>New Style 50% Off</h5>
      </div>
      <div class="col-md-4 ">
        <div class="blog-img ">
          <img src="images/blog444.jpg">
        </div>
        <h5>Buy 1 Get 1 free</h5>
      </div>
      <div class="col-md-4">
        <div class="blog-img">
          <img src="images/hat2.jpeg">
        </div>
        <h5>New Hat Collection</h5>
      </div>
    </div>
  </div>
</section>


<!--------FASHION BRANDS-------->

<section class="fashion-brands">
  <div class="title-style text-center">
    <h1>OUR FASHION BRANDS</h1>
  </div>
  <div class="container">
    <div class="row text-center">
<div class="col-md-3">
  <div class="brand-logo">
  <img src="images/brand4.jpg">
</div>
<p>EXCLUSIVE OFFERS</p>
</div>
<div class="col-md-3">
  <div class="brand-logo">
    <img src="images/brand6.jpg">
  </div>
  <p>MIN. 40% OFF</p>
</div>
<div class="col-md-3">
  <div class="brand-logo">
    <img src="images/brandd2.png">
  </div>
  <p>FREE DELIVERY</p>
</div>
<div class="col-md-3">
  <div class="brand-logo">
    <img src="images/brand5.png">
  </div>
  <p>UP TO 50% OFF</p>
</div>
    </div>
  </div>

</section>

<!--------footer-------->

<section class="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="payment text-center">
        <h5 class="text-center">PAYMENT GATEWAYS</h5>
        <img src="images/pay.jpg">
      </div>
    </div>
      <div class="col-md-4">
        <div class="insta-img text-center">
          <h5 class="text-center">INSTAGRAM PICS</h5>
          <img src="images/instagram1.jpg">
          <img src="images/instagram2.jpg">
          <img src="images/instagram4.jpg">
          <img src="images/instagram5.jpg">
        </div>
      </div>
      <div class="col-md-4">
        <div class="app-download text-center">
          <h5 class="text-center">DOUNLOAD MOBILE APP</h5>
          <img src="images/pay1 (1).png">
          <img src="images/pay2.png">
        </div>
      </div>
    </div>
    </div>
  </div>
</section>


<!------------------contact--------------->
<section class="contact">
  <div id="contact">
  <div class="container">
      <div class="row">
          <div class="contact-left">
              <h1 class="sub-title">Contact Me</h1>
              <p><i class="fas fa-paper-plane"></i>ramazigogitidze1996@gmail.com</p>
              <p><i class="fas fa-phone-alt"></i>+995595604261</p>
              <div class="social-icons">
                  <a href="https://facebook.com"><i class="fab fa-facebook"></i></a>
                  <a href=""><i class="fab fa-twitter-square"></i></a>
                  <a href=""><i class="fab fa-instagram"></i></a>
                  <a href=""><i class="fab fa-linkedin"></i></a>
              </div>
          <div class="aa">
              <br><br><a href="cv.zip" download class="bt">Download CV</a>
          </div></div>
          <div class="contact-right">
              <form action="email.php" method="post" autocomplete="off" >
                  <input type="text" name="name" placeholder="Your Name"   required >
                  <input type="email" name="email" placeholder="Your Email"  required>
                  <textarea name="message" rows="6" placeholder="Your Message"></textarea>
                  <input type="submit" name="send" value="Submit" class="btn btn2">
              </form>
          </div>
      </div>
  </div>
  <div class="copyright">
      <p>Copyright Ramo. Made with <i class="fas fa-heart"></i> by Easy Tutorials</p>
  </div>
      </div> 
    </section>
    <script src="shows.js"></script>
    <script>
    var MenuItems= document.getElementById("MenuItems");
    MenuItems.style.maxHeight = "0px";
    function menutoggle(){
      if( MenuItems.style.maxHeight == "0px"){
        MenuItems.style.maxHeight = "200px"}
     
    else{
      MenuItems.style.maxHeight = "0px"
    }}
   </script>
</body>
</html>